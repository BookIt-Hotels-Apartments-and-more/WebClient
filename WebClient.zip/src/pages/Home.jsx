const Home = () => <div className="p-4">🏠 Home Page</div>;
export default Home;
