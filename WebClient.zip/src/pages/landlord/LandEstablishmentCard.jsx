import { useEffect, useState } from "react";
import { getApartmentsByEstablishment, deleteApartment } from "../../api/apartmentApi";
import { deleteEstablishment } from "../../api/establishmentsApi";
import { Link } from "react-router-dom";
import { getAllBookings } from "../../api/bookingApi";
import { getAllReviews } from "../../api/reviewApi";


//  
const LandEstablishmentCard = ({ est }) => {
  const [apartments, setApartments] = useState([]);
  const [showAddApartment, setShowAddApartment] = useState(false);
  const [newApartment, setNewApartment] = useState({ name: "", price: 0 }); 
  const [bookings, setBookings] = useState([]);  
  const [reviews, setReviews] = useState([]);

//   useEffect(() => {
//     getApartmentsByEstablishment(est.id)
//       .then(setApartments)
//       .catch(console.error);
//   }, [est]);

//   useEffect(() => {
//   getAllBookings().then(data => {
//     const related = data.filter(b => apartments.some(a => a.id === b.apartmentId));
//     setBookings(related);
//   });
// }, [apartments]);

// useEffect(() => {
//   getAllReviews().then(data => {
//     const related = data.filter(r => apartments.some(a => a.id === r.apartmentId));
//     setReviews(related);
//   });
// }, [apartments]);

useEffect(() => {
  setApartments([
    { id: 1, name: "Номер 1", price: 1200 },
    { id: 2, name: "Номер 2", price: 1500 },
  ]);

  setBookings([
    { id: 1, userId: 10, apartmentId: 1, dateFrom: "2024-06-01", dateTo: "2024-06-05" },
  ]);

  setReviews([
    { id: 1, apartmentId: 1, rating: 5, text: "Чудовий сервіс!" },
    { id: 2, apartmentId: 2, rating: 4, text: "Все добре, але шумно." },
  ]);
}, []);


  const handleDeleteHotel = () => {
    if (confirm("Ви впевнені, що хочете видалити готель?")) {
      deleteEstablishment(est.id).then(() => {
        window.location.reload();
      });
    }
  };

  const handleDeleteApartment = (id) => {
    if (confirm("Видалити номер?")) {
      deleteApartment(id).then(() => {
        setApartments((prev) => prev.filter((a) => a.id !== id));
      });
    }
  };

  const handleChangeApartment = (e) => {
  setNewApartment({ ...newApartment, [e.target.name]: e.target.value });
};

const handleAddApartment = async (e) => {
  e.preventDefault();
  try {
    const data = {
      ...newApartment,
      establishmentId: est.id,
    };
    const created = await createApartment(data);
    setApartments([...apartments, created]);
    setNewApartment({ name: "", price: 0 });
    setShowAddApartment(false);
  } catch (err) {
    console.error("Помилка створення номера:", err);
  }
};

  return (
    <div className="card mb-4 shadow-sm">
      <div className="card-body">
        <h5 className="card-title">{est.name}</h5>
        <p className="text-muted">
        Загальна кількість номерів: {apartments.length}
        </p>

        <p className="card-text text-muted">{est.location}</p>
        <p className="card-text">{est.description}</p>
        <button className="btn btn-danger btn-sm me-2" onClick={handleDeleteHotel}>
          Видалити готель
        </button>
        <Link to={`/edit-hotel/${est.id}`} className="btn btn-outline-primary btn-sm">
          Редагувати
        </Link>

        <hr />

        <button
            className="btn btn-sm btn-outline-success mb-3"
            onClick={() => setShowAddApartment(true)}
            >
            ➕ Додати номер
            </button>

            {showAddApartment && (
            <form
                onSubmit={handleAddApartment}
                className="border p-3 mb-3 rounded bg-light"
            >
                <div className="mb-2">
                <input
                    type="text"
                    className="form-control"
                    name="name"
                    placeholder="Назва"
                    value={newApartment.name}
                    onChange={handleChangeApartment}
                    required
                />
                </div>
                <div className="mb-2">
                <input
                    type="number"
                    className="form-control"
                    name="price"
                    placeholder="Ціна"
                    value={newApartment.price}
                    onChange={handleChangeApartment}
                    required
                />
                </div>
                <button className="btn btn-primary btn-sm" type="submit">Додати</button>
            </form>
            )}

        <hr />
        <h6>Номери:</h6>
        {apartments.map((apt) => (
          <div key={apt.id} className="border p-2 mb-2 rounded d-flex justify-content-between">
            <div>
              🛏 {apt.name} — {apt.price}₴
            </div>
            <div>
              <button className="btn btn-outline-danger btn-sm" onClick={() => handleDeleteApartment(apt.id)}>
                Видалити
              </button>
              <Link to={`/edit-apartment/${apt.id}`} className="btn btn-outline-secondary btn-sm ms-2">
                Редагувати
              </Link>
            </div>
          </div>
        ))}

        <hr />

        <h6 className="mt-4">Бронювання:</h6>
            {bookings.length === 0 ? (
            <p className="text-muted">Немає бронювань</p>
            ) : (
            <ul className="list-group">
                {bookings.map((b) => (
                <li key={b.id} className="list-group-item d-flex justify-content-between">
                    <div>
                    🧑 Користувач {b.userId} — {b.dateFrom} ➝ {b.dateTo}
                    </div>
                    <div>
                    <button className="btn btn-sm btn-outline-success me-2">Підтвердити</button>
                    <button className="btn btn-sm btn-outline-danger">Скасувати</button>
                    </div>
                </li>
                ))}
            </ul>
            )}

            <hr />

        <h6 className="mt-4">Відгуки:</h6>
            {reviews.length === 0 ? (
            <p className="text-muted">Відгуків поки немає</p>
            ) : (
            <ul className="list-group">
                {reviews.map((r) => (
                <li key={r.id} className="list-group-item">
                    ⭐ {r.rating}/5: {r.text}
                </li>
                ))}
            </ul>
            )}

        

      </div>
    </div>
  );
};

export default LandEstablishmentCard;
