import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getEstablishmentsByOwner } from "../../api/establishmentsApi";
import LandEstablishmentCard from "./LandEstablishmentCard";

const LandPanel = ({ onClose }) => {
  const user = useSelector((state) => state.user.user);
  const [establishments, setEstablishments] = useState([]);

  // useEffect(() => {
  //   if (!user?.id) return;
  //   getEstablishmentsByOwner(user.id)
  //     .then(setEstablishments)
  //     .catch(console.error);
  // }, [user]);

  useEffect(() => {
 
  setEstablishments([
    {
      id: 1,
      name: "Hotel Testova",
      location: "Київ, Україна",
      description: "Затишний готель у центрі міста",
    },
  ]);
}, []);


  return (
    <div className="container mt-4">
      {onClose && <button onClick={onClose} className="btn-close float-end" />}
      <h2 className="mb-4">Панель партнера</h2>

      {establishments.map((est) => (
        <LandEstablishmentCard key={est.id} est={est} />
      ))}
    </div>
  );
};

export default LandPanel;
