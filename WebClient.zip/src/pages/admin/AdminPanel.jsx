import React from 'react';
import { useSelector } from 'react-redux';

const AdminPanel = ({ onClose }) => {
  
  return (
    <div className="user-panel">
      {onClose && <button onClick={onClose}>✖</button>}
      <h2>Admin Panel</h2>
      <p>Welcome адмін</p>
      {/* Додати функціонал адміна */}
    </div>
  );
};

// const AdminPanel = ({ user: propUser, onClose }) => {
//   const user = propUser || useSelector((state) => state.user.user);

//   if (!user) {
//     return <p>Користувач не знайдений</p>; 
//   }

//   return (
//     <div className="user-panel">
//       {onClose && <button onClick={onClose}>✖</button>}
//       <h2>Admin Panel</h2>
//       <p>Welcome, {user.username}!</p>
//       {/* Додати функціонал адміна */}
//     </div>
//   );
// };

export default AdminPanel;
