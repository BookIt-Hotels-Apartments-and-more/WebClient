const Register = () => <div className="p-4">📝 Register Page</div>;
export default Register;
