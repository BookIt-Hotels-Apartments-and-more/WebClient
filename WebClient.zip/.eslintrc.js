module.exports = {
  extends: [
    'plugin:react/recommended',
    'eslint:recommended',
    'prettier'
  ]
};
